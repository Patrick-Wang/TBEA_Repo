package com.speed.frame.model.entity;

public abstract class AbstractReadOnlyEntity extends AbstractEntity {
	protected AbstractReadOnlyEntity() {
		super();
	}
}
