/** Automatically generated file. DO NOT MODIFY */
package com.tbea.dataviewer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}