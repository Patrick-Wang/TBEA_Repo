package com.ctrl;

public interface IScrollLocker {
	public boolean isEnableScroll();

	public void setEnableScroll(boolean enableScroll);

}
