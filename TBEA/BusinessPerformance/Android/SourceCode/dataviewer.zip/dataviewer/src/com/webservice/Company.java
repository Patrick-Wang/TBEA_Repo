package com.webservice;

public class Company {
	private String name;
	private int id;
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public Company(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	
}
