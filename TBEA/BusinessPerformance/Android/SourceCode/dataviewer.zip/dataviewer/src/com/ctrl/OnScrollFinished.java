package com.ctrl;

import android.view.View;

public interface OnScrollFinished {
	void onScrollFinished(View scroll);
}
