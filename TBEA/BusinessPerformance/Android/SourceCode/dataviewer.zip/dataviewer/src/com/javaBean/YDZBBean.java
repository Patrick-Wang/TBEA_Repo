package com.javaBean;

public class YDZBBean {
	//序号
	private String xh;
	//指标类型
	private String zblx;
	//指标名称
	private String zbmc;
	//本月计划
	private String byjh;
	//本月完成
	private String bywc;
	//计划完成率
	private String jhwcl;
	//上月完成
	private String sywc;
	//较上月增长比
	private String jsyzzb;
	//去年同期
	private String qntq;	
	//较去年同期增长比
	private String jqntqzzb;
	//季度计划
	private String jdjh;
	//季度累计
	private String jdlj;
	//季度计划完成率
	private String jdjhwcl;
	//年度计划
	private String ndjh;
	//年度累计
	private String ndlj;
	//年度计划完成率
	private String ndjhwcl;
	//去年同期累计
	private String qntqlj;
	//较去年同期累计增长比
	private String jqntqljzzb;
	public String getXh() {
		return xh;
	}
	public void setXh(String xh) {
		this.xh = xh;
	}
	public String getZblx() {
		return zblx;
	}
	public void setZblx(String zblx) {
		this.zblx = zblx;
	}
	public String getZbmc() {
		return zbmc;
	}
	public void setZbmc(String zbmc) {
		this.zbmc = zbmc;
	}
	public String getByjh() {
		return byjh;
	}
	public void setByjh(String byjh) {
		this.byjh = byjh;
	}
	public String getBywc() {
		return bywc;
	}
	public void setBywc(String bywc) {
		this.bywc = bywc;
	}
	public String getJhwcl() {
		return jhwcl;
	}
	public void setJhwcl(String jhwcl) {
		this.jhwcl = jhwcl;
	}
	public String getSywc() {
		return sywc;
	}
	public void setSywc(String sywc) {
		this.sywc = sywc;
	}
	public String getJsyzzb() {
		return jsyzzb;
	}
	public void setJsyzzb(String jsyzzb) {
		this.jsyzzb = jsyzzb;
	}
	public String getQntq() {
		return qntq;
	}
	public void setQntq(String qntq) {
		this.qntq = qntq;
	}
	public String getJqntqzzb() {
		return jqntqzzb;
	}
	public void setJqntqzzb(String jqntqzzb) {
		this.jqntqzzb = jqntqzzb;
	}
	public String getJdjh() {
		return jdjh;
	}
	public void setJdjh(String jdjh) {
		this.jdjh = jdjh;
	}
	public String getJdlj() {
		return jdlj;
	}
	public void setJdlj(String jdlj) {
		this.jdlj = jdlj;
	}
	public String getJdjhwcl() {
		return jdjhwcl;
	}
	public void setJdjhwcl(String jdjhwcl) {
		this.jdjhwcl = jdjhwcl;
	}
	public String getNdjh() {
		return ndjh;
	}
	public void setNdjh(String ndjh) {
		this.ndjh = ndjh;
	}
	public String getNdlj() {
		return ndlj;
	}
	public void setNdlj(String ndlj) {
		this.ndlj = ndlj;
	}
	public String getNdjhwcl() {
		return ndjhwcl;
	}
	public void setNdjhwcl(String ndjhwcl) {
		this.ndjhwcl = ndjhwcl;
	}
	public String getQntqlj() {
		return qntqlj;
	}
	public void setQntqlj(String qntqlj) {
		this.qntqlj = qntqlj;
	}
	public String getJqntqljzzb() {
		return jqntqljzzb;
	}
	public void setJqntqljzzb(String jqntqljzzb) {
		this.jqntqljzzb = jqntqljzzb;
	}	
}
