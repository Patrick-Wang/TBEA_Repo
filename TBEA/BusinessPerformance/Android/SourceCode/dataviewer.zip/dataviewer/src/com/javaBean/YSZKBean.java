package com.javaBean;

public class YSZKBean {
	//企业编号
	private String qybh;
	//企业名称
	private String qymc;
	//应收余额
	private String ysye;
	//逾期款
	private String yqk;
	//日回款
	private String rhk;
	//日签约
	private String rqy;
	//月回款
	private String yhk;
	//月签约
	private String yqy;
	//数据日期
	private String sjrq;
	
	public String getQybh() {
		return qybh;
	}
	public void setQybh(String qybh) {
		this.qybh = qybh;
	}
	public String getSjrq() {
		return sjrq;
	}
	public void setSjrq(String sjrq) {
		this.sjrq = sjrq;
	}
	public String getYhk() {
		return yhk;
	}
	public void setYhk(String yhk) {
		this.yhk = yhk;
	}
	public String getYqy() {
		return yqy;
	}
	public void setYqy(String yqy) {
		this.yqy = yqy;
	}
	public String getQymc() {
		return qymc;
	}
	public void setQymc(String qymc) {
		this.qymc = qymc;
	}
	public String getYsye() {
		return ysye;
	}
	public void setYsye(String ysye) {
		this.ysye = ysye;
	}
	public String getYqk() {
		return yqk;
	}
	public void setYqk(String yqk) {
		this.yqk = yqk;
	}
	public String getRhk() {
		return rhk;
	}
	public void setRhk(String rhk) {
		this.rhk = rhk;
	}
	public String getRqy() {
		return rqy;
	}
	public void setRqy(String rqy) {
		this.rqy = rqy;
	}
	
}
