package com.tbea.ic.weixin.service.weixin;

public interface WeiXinService {

	void transferOrg();

	void transferPersion();


}
