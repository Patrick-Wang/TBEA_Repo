package com.tbea.ic.weixin.model.dao.persion;

import java.util.List;

import com.tbea.ic.weixin.model.entity.PersionEntity;


public interface PersionDao {

	List<PersionEntity> getAllPersion();

}
