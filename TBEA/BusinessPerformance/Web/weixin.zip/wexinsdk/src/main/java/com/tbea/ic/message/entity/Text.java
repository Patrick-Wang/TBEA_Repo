package com.tbea.ic.message.entity;

public class Text {
	String content;

	public Text(String content) {
		super();
		this.content = content;
	}
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
